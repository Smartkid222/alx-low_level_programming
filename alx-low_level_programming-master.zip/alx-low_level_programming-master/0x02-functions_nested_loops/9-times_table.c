#include "main.h"

/**
 * times_table - function that prints the 9 times table
 * Return: 0
 */

void times_table(void)
{
	int n;
	int i;
	int s;
	int k;
	int j;

	for (n = 0 ; n <= 9 ; n++)
	{
	for (i = 0; i <= 9; i++)
	{
	s = n + i;
	if (s > 9)
	{
		k = s % 10;
		j = (s - k) / 10;
		_putchar(44);
		_putchar(32);
		_putchar(j + '0');
		_putchar(k + '0');
	}
	else
	{
		if (i != 0)
		{
			_putchar(44);
			_putchar(32);
		}
		_putchar(s + '0');
	}
	}
		_putchar('\n');
	}
	return (0);
}
