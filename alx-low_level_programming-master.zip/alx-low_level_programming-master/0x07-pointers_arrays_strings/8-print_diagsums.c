#include "main.h"
#include <stdio.h>
/**
 * print_diagsums - function that prints the sum of the two diagonals
 * @a: diagonal 1
 * @size: diagonal 2
 * Return: 0
 */
void print_diagsums(int *a, int size)
{
	int i;
	int n;
	int y;

	i = 0;
	n = 0;

	for (y = 0; y < size; y++)
	{
		i = i + a[y * size + y];
	}
	for (y = size - 1; y >= 0; y--)
	{
		n += a[y * size + (size - 1 - y)];
	}
	printf("%d, %d\n", i, n);
}
