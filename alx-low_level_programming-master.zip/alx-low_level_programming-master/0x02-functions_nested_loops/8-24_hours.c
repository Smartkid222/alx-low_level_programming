#include "main.h"

/**
 * jack_bauer - function that prints every minute of the day of Jack Bauer
 *
 * Return: 0
 */

void jack_bauer(void)
{
	int s;
	int k;

	for (s = 0 ; s < 24 ; s++)
	{
		for (k = 0 ; k < 60 ; k++)
		{
			_putchar(s / 10 + '0');
			_putchar(s % 10 + '0');
			_putchar(':');
			_putchar(k / 10 + '0');
			_putchar(k % 10 + '0');
			_putchar('\n');
		}
	}
}
