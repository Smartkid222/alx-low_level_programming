#include "main.h"

/**
 * print_times_table - function that prints the n times table
 *
 * @n: parameter function
 *
 * Return: 0
 */

void print_times_table(int n)
{

