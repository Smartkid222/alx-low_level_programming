#include <stdio.h>

/**
 * main - main
 *
 * Return: 0
 */

int main(void)
{
	int i;
	int s;
	int k;

	for (i = 0 ; i < 10 ; i++)
	{
		for (s = 1 ; s < 10 ; s++)
		{
			for (k = 2 ; k < 10 ; k++)
			{
				if (i < s && s < k)
				{
					putchar(i + '0');
					putchar(s + '0');
					putchar(k + '0');
					if (i + s + k != 24)
					{
						putchar(',');
						putchar(' ');
					}
				}
			}
		}
	}
	putchar('\n');
	return (0);
}
