#include "function_pointers.h"

/**
 * int_index - function that searches for an integer
 * @array: integer 1
 * @size: integer 2
 * @cmp: integer 3
 * Return: 0
 */

int int_index(int *array, int size, int (*cmp)(int))
{
	int s;

	if (array == NULL || size <= 0 || cmp == NULL)
		return (-1);
	for (s = 0; s < size; s++)
	{
		if (cmp(array[s]))
			return (1);
	}
	return (-1);
}
