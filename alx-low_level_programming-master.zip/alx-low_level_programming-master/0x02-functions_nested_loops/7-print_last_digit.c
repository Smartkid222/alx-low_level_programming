#include "main.h"

/**
 * print_last_digit - print last digit
 *
 * @s: parameter for last digit
 *
 * Return: k
 */

int print_last_digit(int s)
{
	int k;

	k = s % 10;
	if (s < 0)
		k = -k;
	_putchar(k + '0');
	return (k);
}
