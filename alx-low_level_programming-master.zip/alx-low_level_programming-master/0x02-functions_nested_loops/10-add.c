#include "main.h"

/**
 * add - function that adds two integers and returns the result
 *
 * @a: para 1
 *
 * @b: para 2
 *
 * Return: a + b
 */

int add(int a, int b)
{
	return (a + b);
}
