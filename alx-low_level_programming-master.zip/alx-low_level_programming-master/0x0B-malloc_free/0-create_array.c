#include "main.h"
#include <stdio.h>
#include <stdlib.h>

/**
 * create_array - function that creates an array of chars
 * @size: char 1
 * @c: char 2
 * Return: 0
 */

char *create_array(unsigned int size, char c)
{
	char *s;
	int i = 0;

	if (size == 0)
		return (NULL);
	s = (char *) malloc(sizeof(char) * size);
	if (s == NULL)
		return (NULL);
	while (i < size)
		s[i] = 0;
	i++;
	return (s);
}
