#include "main.h"
#include <stdio>

/**
 * positive_or_negative - print positive and negative numbers
 *
 * @i: parameter for printing
 *
 * Return: 0
 */
void positive_or_negative(int i)
{
	int i;

	if (i < 0)
		printf("%d is negative", i);
	else
		printf("%d is positive", i);
}
