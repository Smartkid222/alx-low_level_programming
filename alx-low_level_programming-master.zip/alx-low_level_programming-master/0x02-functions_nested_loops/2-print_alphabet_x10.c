#include "main.h"

/**
 * print_alphabet_x10 - function that print alphabet 10x
 *
 * Return: Always 0.
 */

void print_alphabet_x10(void)
{
	int s;
	char k;

	for (s = 1 ; s <= 10 ; s++)
	{
		for (k = 'a' ; k <= 'z' ; k++)
			_putchar(k);
		_putchar('\n');
	}
}
