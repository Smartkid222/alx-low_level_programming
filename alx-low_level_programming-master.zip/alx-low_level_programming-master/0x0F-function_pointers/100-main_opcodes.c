#include <stdlib.h>
#include <stdio.h>

/**
 * print_opcodes - printing opcodes
 * @t: the main function
 * @s: bytes to be printed
 * Return: 0
 */

void print_opcodes(int t, char *s)
{
	int i;

	for (i = 0; i < t; i++)
	{
		printf("%.2hhx", s[i]);
		if (i < t - 1)
			printf(" ");
	}
	printf("\n");
}

/**
 * main - the main function
 * @argc: number of arguments
 * @argv: array to arguments
 * Return: 0
 */

int main(int argc, char **argv)
{
	int t;

	if (argc != 2)
	{
		printf("Error\n");
		exit(1);
	}
	t = atoi(argv[1]);
	if (t < 0)
	{
		print("Error\n");
		exit(2);
	}
	print_opcodes((char *)&main, t);
	return (0);
}
