#include "main.h"

/**
 * reset_to_98 - function that takes a pointer
 * @n: the value to be replace
 * Return: 0
 */

void reset_to_98(int *n)
{
	*n = 98;
}
