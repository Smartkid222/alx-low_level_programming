#include <stdio.h>

/**
 * main - main
 *
 * Return: 0
 */

int main(void)
{
	int i;
	int s;

	for (i = 0 ; i < 10 ; i++)
	{
		for (s = 1 ; s < 10 ; s++)
		{
			if (i < s && i != s)
			{
				putchar(i + '0');
				putchar(s + '0');
				if (i + s != 17)
				{
					putchar(',');
					putchar(' ');
				}
			}
		}
	}
	putchar('\n');
	return (0);
}
